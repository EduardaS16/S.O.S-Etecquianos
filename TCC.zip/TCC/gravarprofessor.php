<?php
include './conexao.php';//incluir o arquivo conexao.php
$nome = $_POST["txtNome"];//Pega o valor da caixa de texto
$email = $_POST["txtEmail"];//Pega o valor da caixa de texto
$senha = $_POST["txtSenha"];
$sql = 
"insert into professor values(null,'$nome','$email',md5('$senha'))";//Monta o comando Sql
//Executa o comando especificando os dados da conexÃ£o e o comando sql
if(mysqli_query($conexao, $sql)){
    echo "<script>alert('Dados gravados com sucesso!');"
    . "window.location='login.html';"
            . "</script>";
}else{
    echo mysqli_error($conexao);
}
?>