<?php
include './conexao.php';//incluir o arquivo conexao.php
$nome = $_POST["txtNome"];//Pega o valor da caixa de texto
$sql = 
"insert into materia values(null,'$nome')";//Monta o comando Sql
//Executa o comando especificando os dados da conexÃ£o e o comando sql
if(mysqli_query($conexao, $sql)){
    echo "<script>alert('Dados gravados com sucesso!');"
    . "window.location='cadastromateria.php';"
            . "</script>";
}else{
    echo mysqli_error($conexao);
}
?>