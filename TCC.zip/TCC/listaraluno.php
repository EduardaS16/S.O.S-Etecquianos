<?php
include './conexao.php';
$nome = $_POST["txtNome"];
$sql = 
"SELECT aluno.*,serie.serie,serie.ano FROM aluno,serie WHERE aluno.nome LIKE '%$nome%'
and aluno.idSerie = serie.id";
$result = mysqli_query($conexao, $sql);
echo "<table border='1'>"
        . "<tr>"
        . "<td>Nome</td>"
        . "<td>Data de Nascimento</td>"
        . "<td>Série</td>"
        . "<td>Email</td>"
        . "</tr>";
while($dados=mysqli_fetch_array($result)) {
    $nome = $dados["nome"];
    $data_de_nascimento=$dados["data_de_nascimento"];
    $serie=$dados["serie"];
    $ano = $dados["ano"];
    $email = $dados["email"];
    echo "<tr>"
        . "<td>$nome</td>"
        . "<td>$data_de_nascimento</td>"
        . "<td>$serie/$ano</td>"
        . "<td>$email</td>"
        . "</tr>";
}
echo "</table>";
echo "<a href='cadastroaluno.php'>Voltar</a>";
?>