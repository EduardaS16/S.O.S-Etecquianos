<?php
session_start();
$_SESSION["id"] = "";//isso é um migué. Depois arrumamos
        if(isset($_SESSION["id"])){
include './conexao.php';//incluir o arquivo conexao.php
$idProfessor= $_POST["txtProfessor"];
$idMateria= $_POST["txtMateria"];
$sql = 

"insert into materiaprofessor values(null,'$idProfessor','$idMateria')";
    
if(mysqli_query($conexao, $sql)){
    echo "<script>alert('Dados gravados com sucesso!');"
    . "window.location='materiaprof.php';"
            . "</script>";
}else{
    echo mysqli_error($conexao);
}
 }else{
            echo "<p>Usuário não logado.</p>";
            echo "<a href='login.html'>Faça seu login</a>";
        }
?>
