<html>
    <head>
        <meta charset="UTF-8">
        <title>Perguntas</title>
        <link rel="stylesheet" href="css/estilo.css">
    </head>
    <body>
  
 
        <div class="topo">
            <div>
            <img src="imagens/logo.png">
            </div>
            <div class="menu" style="width: 55%;">
                <ul>
                    <a href="index.php"><li>Home</li></a>
                   
                    <a href="login.html"> <li>Login</li></a>
                </ul>
            </div>
        </div>
          <div class="perguntas">
        <?php
  
        include 'topo.php';
        if(isset($_SESSION["idAluno"])){
        ?>
              <div class="cadastro">
             <form method="POST" action="gravarpergunta.php">
                 <p>Faça sua pergunta</p>
             
             <div><textarea name="txtPergunta" rows="4" cols="50"></textarea></div>
            
             <div><label>Matéria</label>
                <select name="txtMateria">
        
  <option value="0">::Escolha a matéria::</option>
                <?php
                include './conexao.php';
                mysqli_set_charset($conexao, "utf8");
                $sql = "SELECT * FROM materia ORDER BY nome";
                $result = mysqli_query($conexao, $sql);
                while ($dados = mysqli_fetch_array($result)) {
                    $idMateria = $dados["id"];
                 $nome=$dados["nome"];
                 
                    echo "<option value='$idMateria'>$nome</option>";
                }
                ?>
            </select>
                 
                 <br>
                 <br>
                 <div class="cadastro2">
      
            <input type="submit" value="Gravar"></div>
                 
             </div> 
          
              </div>
      
</form>
       
             
                  
                  
                       
                  <?php
                  $idAluno = $_SESSION["idAluno"];
                    include './conexao.php';
                mysqli_set_charset($conexao, "utf8");
                $sql = "SELECT * FROM perguntaresposta 
WHERE idAluno = '$idAluno'
and resposta <> '' ORDER BY pergunta";
                $result = mysqli_query($conexao, $sql);
                while ($dados = mysqli_fetch_array($result)) {
                    $pergunta = $dados["pergunta"];
                 $resposta = $dados["resposta"];
                 
              
                    echo "<h3><img src='imagens/pergunta3.png'><strong> $pergunta</strong></h3>";
                    echo"<p><img src='imagens/resposta.png'><strong>$resposta</strong><p>";
                    echo "<hr>";
                }
                  ?>
                  <?php
        }else{
            echo "<p>Usuário não logado.</p>";
            echo "<a href='login.html'>Faça seu login</a>";
        }
        ?>
          <br><br><br><br>
          <center>        <p>É um etecquiano e ainda não possui cadastro?</p>
              <p><a href="cadastroaluno.php">CADASTRE-SE JÁ</a></p>
        </div>
       
        <BR>
  
 

         <div class="rodape">  
              <br>
           <br>
             <br>
           <br>
             <br>
           <br>
             <br>
           <br>  <br>
           
              <center> <footer>
     <small>&copy; Copyright 2018, sosetecquiano@gmail.com </small>
            </footer>   </center>
        </div>
        
      
    </body>
</html>
