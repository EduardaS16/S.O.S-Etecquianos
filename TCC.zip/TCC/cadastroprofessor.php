
<html>
    <head>
        <meta charset="UTF-8">
        <title>Cadastre-se</title>
        <link rel="stylesheet" href="css/estilo.css">
    </head>
    <body>
        <a href="cadastroprofessor.php"></a>
        <div class="topo">
            <div>
            <img src="imagens/logo.png">
            </div>
            <div class="menu" style="width: 55%;">
                <ul>
                    <a href="index.php"><li>Home</li></a>
                </ul>
            </div>
        </div>
             
        <div class="perguntas"><br>
               <form method="post" action="gravarprofessor.php"> 
                   <p>Cadastro de Professor</p>
    <div class="cadastro">
      
    <div><label>Nome</label></div>
    <div><input type="text" name="txtNome"></div>
    <div><label>Email</label></div>
    <div><input type="text" name="txtEmail"></div>
    <div><label>Senha</label></div>
    <div><input type="password" name="txtSenha"></div>

          <div class="cadastro2">
    <input type="submit" value="Gravar">
    </div>
    </div></form>

    </div></div>
        
         <div class="rodape">  
              <br>
           <br>
             <br>
           <br>
             <br>
           <br>
             <br>
           <br>  <br>
           
              <center> <footer>
     <small>&copy; Copyright 2018, sosetecquiano@gmail.com </small>
            </footer>   </center>
        </div>
        
      
    </body>
</html>
        