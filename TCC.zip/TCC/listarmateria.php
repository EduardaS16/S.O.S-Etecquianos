<?php
include './conexao.php';
$nome = $_POST["txtNome"];
$sql = 
"SELECT id,nome FROM materia WHERE nome LIKE '%$nome%'";
$result = mysqli_query($conexao, $sql);
echo "<table border='1'>"
        . "<tr>"
        . "<td>Nome</td>"
        . "</tr>";
while($dados=mysqli_fetch_array($result)) {
    $nome = $dados["nome"];
    echo "<tr>"
        . "<td>$nome</td>"
        . "</tr>";
}
echo "</table>";
echo "<a href='cadastroaluno.php'>Voltar</a>";
?>