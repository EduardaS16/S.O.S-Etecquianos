<?php
include './conexao.php';
$nome = $_POST["txtNome"];
$sql = 
"SELECT id,nome,ano FROM serie WHERE nome LIKE '%$nome%'";
$result = mysqli_query($conexao, $sql);
echo "<table border='1'>"
        . "<tr>"
        . "<td>Nome</td>"
        . "<td>Ano</td>"
        . "</tr>";
while($dados=mysqli_fetch_array($result)) {
    $nome = $dados["nome"];
    $ano = $dados["ano"];
    echo "<tr>"
        . "<td>$nome</td>"
        . "<td>$ano</td>"
        . "</tr>";
}
echo "</table>";
echo "<a href='cadastroserie.php'>Voltar</a>";
?>