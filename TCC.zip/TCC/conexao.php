<?php

$bdServidor = 'localhost';
$bdUsuario = 'root';
$bdSenha = '';
$bdBanco = 'etecquiano';
$conexao = mysqli_connect($bdServidor, 
        $bdUsuario, $bdSenha, $bdBanco);

//Na funÃ§Ã£o mysqli_connect especificamos o servidor, usuario, senha e nome do banco de dados
?>