<html>
    <head>
        <meta charset="UTF-8">
        <title>Cadastre-se</title>
        <link rel="stylesheet" href="css/estilo.css">
    </head>
    <body>
 
        <div class="topo">
            <div>
            <img src="imagens/logo.png">
            </div>
            <div class="menu" style="width: 55%;">
                <ul>
                    <a href="index.php"><li>Home</li></a>
                   
                    <a href="login.html"> <li>Login</li></a>
                </ul>
            </div>
        </div>
    
        

  <div class="perguntas">
      <center><br>
 <form method="POST" action="gravaraluno.php">
     <p> Cadastro de Aluno</p>
        <div class="cadastro">
            <div><label>Nome</label></div>
            <div><input type="text" name="txtNome"></div>
            <div><label>Data de Nascimento</label></div>
            <div><input type="date" name="txtdata"></div>
            <div><label>Série</label></div>
            <div><select name="txtSerie">

                <option value="0">::Escolha a série::</option>
                <?php
                include './conexao.php';
                $sql = "SELECT * FROM serie ORDER BY serie";
                $result = mysqli_query($conexao, $sql);
                while ($dados = mysqli_fetch_array($result)) {
                    $idSerie = $dados["id"];
                    $serie = $dados["serie"];
                    $ano = $dados["ano"];
                    echo "<option value='$idSerie'>$serie/$ano</option>";
                }
                ?>


            </select></div>
            <div><label>Email</label></div>
            <div><input type="text" name="txtEmail"></div>
            <div><label>Senha</label></div>
            <div><input type="password" name="txtSenha"></div>
            
        </form>
<div class="cadastro2">
         <input type="submit" value="Gravar">
     </div>
</div>
     
      </center>
  </div>
         <div class="rodape">  
              <br>
           <br>
             <br>
           <br>
             <br>
           <br>
             <br>
           <br>  <br>
           
              <center> <footer>
     <small>&copy; Copyright 2018, sosetecquiano@gmail.com </small>
            </footer>   </center>
        </div>
        
      
    </body>
</html>



