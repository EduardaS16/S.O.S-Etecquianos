<?php

$email = $_POST["txtEmail"];
$senha = $_POST["txtSenha"];
$tipo = $_POST["tipo"];

include './conexao.php';
if($tipo == "aluno"){
$sql = "SELECT * FROM aluno WHERE email = '$email' and senha = md5('$senha')";
$result = mysqli_query($conexao, $sql);
$linhas = mysqli_num_rows($result);
if($linhas > 0){
    session_start();
    while($dados=  mysqli_fetch_array($result)){
    $_SESSION["idAluno"] = $dados["id"];
    $_SESSION["email"] = $dados["email"];
            
    }                        
    echo "<script>"
    . "window.location='pergunta.php';"
            . "</script>";
}else{
    echo "<script>"
    . "alert('Dados incorretos! Tente novamente.');"
    . "window.location='login.html';"
            . "</script>";
}
}else if($tipo == "professor"){
 
    $sql = "SELECT * FROM professor WHERE email = '$email' and senha = md5('$senha')";
$result = mysqli_query($conexao, $sql);
$linhas = mysqli_num_rows($result);
if($linhas > 0){
    session_start();
    while($dados=  mysqli_fetch_array($result)){
    $_SESSION["idProfessor"] = $dados["id"];
    $_SESSION["email"] = $dados["email"];        
    }
    echo "<script>"
    . "window.location='listapergunta.php';"
            . "</script>";
}
else{
    echo "<script>"
    . "alert('Dados incorretos! Tente novamente.');"
    . "window.location='login.html';"
            . "</script>";
}
}
 
?>