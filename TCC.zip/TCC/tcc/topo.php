<div class="top">
 <?php
session_start();
if(isset($_SESSION["email"])){
    
    echo "<p>Olá ".$_SESSION["email"]." - <a href='sair.php'>Sair</a></p>";
    
}

?>
</div>