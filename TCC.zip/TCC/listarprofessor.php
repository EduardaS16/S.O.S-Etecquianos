<?php
include './conexao.php';
$nome = $_POST["txtNome"];
$sql = 
"SELECT id,nome,email FROM professor WHERE nome LIKE '%$nome%'";
$result = mysqli_query($conexao, $sql);
echo "<table border='1'>"
        . "<tr>"
        . "<td>Nome</td>"
        . "<td>Email</td>"
        . "</tr>";
while($dados=mysqli_fetch_array($result)) {
    $nome = $dados["nome"];
    $email = $dados["email"];
    echo "<tr>"
        . "<td>$nome</td>"
        . "<td>$email</td>"
        . "</tr>";
}
echo "</table>";
echo "<a href='cadastroprofessor.php'>Voltar</a>";
?>