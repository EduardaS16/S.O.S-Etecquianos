<?php
session_start();
        if(isset($_SESSION["idAluno"])){
include './conexao.php';//incluir o arquivo conexao.php
$pergunta= $_POST["txtPergunta"];
$materia= $_POST["txtMateria"];
$idAluno = $_SESSION["idAluno"];
$sql = 

"insert into perguntaresposta values(null,'$materia','0','$idAluno','$pergunta','')";
    
if(mysqli_query($conexao, $sql)){
    echo "<script>alert('Dados gravados com sucesso!');"
    . "window.location='pergunta.php';"
            . "</script>";
}else{
    echo mysqli_error($conexao);
}
 }else{
            echo "<p>Usuário não logado.</p>";
            echo "<a href='login.html'>Faça seu login</a>";
        }
?>