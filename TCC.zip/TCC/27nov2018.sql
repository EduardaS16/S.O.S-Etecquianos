/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.7.10-log : Database - etecquiano
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`etecquiano` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `etecquiano`;

/*Table structure for table `aluno` */

DROP TABLE IF EXISTS `aluno`;

CREATE TABLE `aluno` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `data_de_nascimento` date NOT NULL,
  `idSerie` tinyint(3) unsigned NOT NULL,
  `email` varchar(60) NOT NULL,
  `senha` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_aluno_idSerie` (`idSerie`),
  CONSTRAINT `FK_aluno_idSerie` FOREIGN KEY (`idSerie`) REFERENCES `serie` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `aluno` */

insert  into `aluno`(`id`,`nome`,`data_de_nascimento`,`idSerie`,`email`,`senha`) values (8,'Gabrielly Fernandes Branco','2001-03-15',5,'gaby.branco77@gmail.com','26c210b154f122faf834f3c3ae60a95b'),(9,'Maria Eduarda da Silva','2001-09-16',5,'dudaduda.silvamd16@gmail.com','fa22129d71442031ea0897d350d69f52'),(10,'Camila Giovana Da Silva','2001-04-24',5,'camilagiovana002@gmail.com','4c2c61c376bcc544ca9f5cb4b3476d81');

/*Table structure for table `materia` */

DROP TABLE IF EXISTS `materia`;

CREATE TABLE `materia` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `materia` */

insert  into `materia`(`id`,`nome`) values (1,'Português'),(2,'Matemática'),(3,'História'),(4,'Geografia'),(5,'Biologia'),(6,'Química'),(7,'Física'),(8,'Artes'),(9,'Educação Física'),(10,'Filosofia'),(11,'Sociologia'),(12,'Empreendedorismo'),(13,'Informática'),(14,'Mecânica'),(15,'Inglês');

/*Table structure for table `materiaprofessor` */

DROP TABLE IF EXISTS `materiaprofessor`;

CREATE TABLE `materiaprofessor` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `idProfessor` tinyint(3) unsigned NOT NULL,
  `idMateria` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_materiaProfessor_idProfessor` (`idProfessor`),
  KEY `FK_materiaProfessor_idMateria` (`idMateria`),
  CONSTRAINT `FK_materiaProfessor_idMateria` FOREIGN KEY (`idMateria`) REFERENCES `materia` (`id`),
  CONSTRAINT `FK_materiaProfessor_idProfessor` FOREIGN KEY (`idProfessor`) REFERENCES `professor` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `materiaprofessor` */

insert  into `materiaprofessor`(`id`,`idProfessor`,`idMateria`) values (4,8,6),(5,7,4),(6,9,13),(7,10,2),(8,6,5);

/*Table structure for table `perguntaresposta` */

DROP TABLE IF EXISTS `perguntaresposta`;

CREATE TABLE `perguntaresposta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idMateria` tinyint(3) unsigned NOT NULL,
  `idProfessor` tinyint(3) unsigned NOT NULL,
  `idAluno` int(10) unsigned NOT NULL,
  `pergunta` varchar(400) DEFAULT NULL,
  `resposta` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_perguntaReposta_idMateria` (`idMateria`),
  KEY `FK_perguntaReposta_idProfessor` (`idProfessor`),
  KEY `FK_perguntaReposta_idAluno` (`idAluno`),
  CONSTRAINT `FK_perguntaReposta_idAluno` FOREIGN KEY (`idAluno`) REFERENCES `aluno` (`id`),
  CONSTRAINT `FK_perguntaReposta_idMateria` FOREIGN KEY (`idMateria`) REFERENCES `materia` (`id`),
  CONSTRAINT `FK_perguntaReposta_idProfessor` FOREIGN KEY (`idProfessor`) REFERENCES `professor` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

/*Data for the table `perguntaresposta` */

insert  into `perguntaresposta`(`id`,`idMateria`,`idProfessor`,`idAluno`,`pergunta`,`resposta`) values (21,4,7,10,'Quantos habitantes tem a cidade de Cruzeiro?','200 mil habitantes\r\n            '),(22,4,7,9,'Qual a base do sistema capitalista?','O lucro.\r\n            ');

/*Table structure for table `professor` */

DROP TABLE IF EXISTS `professor`;

CREATE TABLE `professor` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(60) NOT NULL,
  `senha` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Data for the table `professor` */

insert  into `professor`(`id`,`nome`,`email`,`senha`) values (0,'Nenhum','Nenhum','Nenhum'),(6,'Thiago Bastos Borges','thiago.borges@etec.sp.gov.br','6d071901727aec1ba6d8e2497ef5b709'),(7,'Luiz Eduardo Monteiro','led.mont@yahoo.com','4b7aea5ac9e04f5a96d619068996ee2d'),(8,'Eduardo Ferreira Nunes','edu.peixe@hotmail.com','d00f5a45dbc6391302a6d96053c24ab5'),(9,'Ruama Lorena Ferraz Ramos','etecprofatividades@gmail.com','2d2c50493505cc2922df6ad7fc547f54'),(10,'Simone Silva Julião ','simjv1@hotmail.com','d189d5052d8c9ad33de55b992b8bd2fd');

/*Table structure for table `serie` */

DROP TABLE IF EXISTS `serie`;

CREATE TABLE `serie` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `serie` varchar(30) NOT NULL,
  `ano` char(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `serie` */

insert  into `serie`(`id`,`serie`,`ano`) values (4,'3º EM','2018'),(5,'3º ETIM- Informática','2018'),(6,'3º ETIM-Mecânica','2018'),(7,'2º EM','2018'),(8,'2º ETIM-Informática','2018'),(9,'2º ETIM-Mecânica ','2018'),(10,'1º EM','2018'),(11,'1º ETIM-Informática','2018'),(12,'1º ETIM- Mecânica','2018');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
