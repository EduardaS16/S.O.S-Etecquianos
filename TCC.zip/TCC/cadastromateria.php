<html>
    <head>
        <meta charset="UTF-8">
        <title>SOS Etecquianos</title>
        <link rel="stylesheet" href="css/estilo.css">
    </head>
    <body>
 
        <div class="topo">
            <div>
            <img src="imagens/logo.png">
            </div>
            <div class="menu" style="width: 55%;">
                <ul>
                    <a href="index.php"><li>Home</li></a>
                     <a href="cadastroaluno.php"> <li>Cadastro</li></a>
                </ul>
            </div>
        </div>

        <div class="perguntas">
            <form method="POST" action="gravarmateria.php"><br>
                <p>Cadastro de Matéria</p>
                <div class="cadastro">
    <div><label>Nome</label></div>
   <div> <input type="text" name="txtNome">   </div>
   <div class="cadastro2">
   <div> <input type="submit" value="Gravar"></div>
   </div>
   </div>
</form>   
        </div>

        
 <div class="rodape">  
              <br>
           <br>
             <br>
           <br>
             <br>
           <br>
             <br>
           <br>  <br>
           
              <center> <footer>
     <small>&copy; Copyright 2018, sosetecquiano@gmail.com </small>
            </footer>   </center>
        </div>
        
      
    </body>
</html>


