
<html>
    <head>
        <meta charset="UTF-8">
        <title>SOS Etecquianos</title>
        <link rel="stylesheet" href="css/estilo.css">
    </head>
    <body>

        <div class="topo">
            <div>
                <img src="imagens/logo.png">
            </div>
            <div class="menu" style="width: 55%;">
                <ul>
                    <a href="index.php"><li>Home</li></a>
                    <a href="cadastroaluno.php"> <li>Cadastre-se</li></a>
                    <a href="login.html"> <li>Login</li></a>
                </ul>
            </div>
        </div>


        <!--<div class="pesquisa">
            
        </div>-->

        <form method="post" action="pergunta.php">
            <p style="text-align: center;"><input type="submit" value="Faça sua pergunta" class="botao">  </p>
        </form>
        <br>
        <br>
        
        <form method="post" action="index.php">
            <div class="cadastro">
            <p style="text-align: center;">
                <input type="text" name="txtConsulta" size="60" placeholder="Pesquise aqui sua pergunta" class="pes">
               <input type="image" title="Pesquisar" src="imagens/search.png" style="width:2.5%">
        </div>
        </form>
        <br>
        <br>
        <br>
        <br>
        <br>

        <div class="perguntas">
            <?php
            include './conexao.php';
            mysqli_set_charset($conexao, "utf8");
            if(isset($_POST["txtConsulta"])){
                $consulta = $_POST["txtConsulta"];
                $sql = "SELECT * FROM perguntaresposta WHERE pergunta LIKE '%$consulta%' AND resposta <> '' ORDER BY pergunta, resposta";
            }else{
            $sql = "SELECT * FROM perguntaresposta WHERE resposta <> '' ORDER BY pergunta, resposta";
            }
            $result = mysqli_query($conexao, $sql);
            $linhas = mysqli_num_rows($result);
            if($linhas > 0){
            while ($dados = mysqli_fetch_array($result)) {
                $pergunta = $dados["pergunta"];
                $resposta = $dados["resposta"];


                echo "<h3><img src='imagens/pergunta3.png'><strong> $pergunta</strong></h3>";
                echo"<p><img src='imagens/resposta.png'><strong>$resposta</strong><p>";
                echo "<hr>";
            }
            }else{
                echo "<h3><img src='imagens/pergunta3.png'><strong>Nenhuma pergunta encontrada.</strong></h3>";
            }
            ?>

        </div>
        <br>
        <div class="rodape">  
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>  <br>

            <center> <footer>
                    <small>&copy; Copyright 2018, sosetecquiano@gmail.com </small>
                </footer>   </center>
        </div>




    </body>
</html>
