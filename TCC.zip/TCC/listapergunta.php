
<html>
    <head>
        <meta charset="UTF-8">
        <title>SOS Etecquianos</title>
        <link rel="stylesheet" href="css/estilo.css">
    </head>
    <body>
 
        <div class="topo">
            <div>
            <img src="imagens/logo.png">
            </div>
            <div class="menu" style="width: 55%;">
                <ul>
                    <a href="index.php"><li>Home</li></a>
                </ul>
            </div>
        </div>
    
             
    <body>
             <div class="perguntas">
        <?php
        include 'topo.php';
        if (isset($_SESSION["idProfessor"])) {
            $idProfessor = $_SESSION["idProfessor"];
            
            include './conexao.php';
            mysqli_set_charset($conexao, "utf8");
            $sql = "select pr.id,pr.pergunta 
from perguntaresposta pr,materiaprofessor m,professor p
where p.id = '$idProfessor'
and pr.idProfessor = 0
and p.id = m.idProfessor
and pr.idMateria = m.idMateria
";
            
            $result = mysqli_query($conexao, $sql);
            if(mysqli_num_rows($result) > 0){
            while ($dados = mysqli_fetch_array($result)) {
                $idpergunta=$dados["id"];
                $pergunta = $dados["pergunta"];

                echo "<form method='post' action='alterarresposta.php'>";
                echo "<p>$pergunta</p>";
                echo "<textarea name=\"txtResposta\" rows=\"5\" cols=\"50\">

            </textarea>";
                echo "<input type='hidden' name='idProfessor' value='$idProfessor'>";
                echo "<input type='hidden' name='idPergunta' value='$idpergunta'<br><br><br>";
                echo "<div class='cadastro2'><input type=\"submit\" value=\"Responder\">
               </form></div>";
               
            }
            ?>

            <?php
        }else{
            echo "<p>Não há perguntas no momento. Obrigado!</p>";
        }
        
        }
        else {
            echo "<p>Usuário não logado.</p>";
            echo "<a href='login.html'>Faça seu login</a>";
        }
        ?>
             </div>
         <div class="rodape">  
              <br>
           <br>
             <br>
           <br>
             <br>
           <br>
             <br>
           <br>  <br>
           
              <center> <footer>
     <small>&copy; Copyright 2018, sosetecquiano@gmail.com </small>
            </footer>   </center>
        </div>
        
      
    </body>
</html>
