<html>
    <head>
        <meta charset="UTF-8">
        <title>Cadastro professor</title>
        <link rel="stylesheet" href="css/estilo.css">
    </head>
    <body>
 
        <div class="topo">
            <div>
            <img src="imagens/logo.png">
            </div>
            <div class="menu" style="width: 55%;">
                <ul>
                    <a href="index.php"><li>Home</li></a>
                    <a href="login.html"> <li>Login</li></a>
                </ul>
            </div>
        </div>
    
             
        <!--<div class="pesquisa">
            
        </div>-->
 <div class="perguntas">
      <center><br><br>
  <form method="POST" action="gravarmateriaprof.php">
 
        <div class="cadastro">
       
 <div><label>Professor</label></div>
            <div><select name="txtProfessor">  
        
  <option value="0">::Escolha o professor::</option>
                <?php
                include './conexao.php';
                mysqli_set_charset($conexao, "utf8");
                $sql = "SELECT * FROM professor ORDER BY nome";
                $result = mysqli_query($conexao, $sql);
                while ($dados = mysqli_fetch_array($result)) {
                    $idProfessor = $dados["id"];
                 $nome=$dados["nome"];
                 
                    echo "<option value='$idProfessor'>$nome</option>";
                }
                ?>
            </select></div>
            <div> <label>Matéria</label></div>
           <div> <select name="txtMateria">  
      
        
<option value="0">::Escolha a matéria::</option>
                <?php
                include './conexao.php';
                mysqli_set_charset($conexao, "utf8");
                $sql = "SELECT * FROM materia ORDER BY nome";
                $result = mysqli_query($conexao, $sql);
                while ($dados = mysqli_fetch_array($result)) {
                    $idMateria = $dados["id"];
                 $nome=$dados["nome"];
                 
                    echo "<option value='$idMateria'>$nome</option>";
                }
                ?>
            </select></div><br><br>
<div class="cadastro2">
    <div><input type="submit" value="Gravar"></div>
</div>
        </div>
 </form>
 </div> 
          <div class="rodape">  
              <br>
           <br>
             <br>
           <br>
             <br>
           <br>
             <br>
           <br>  <br>
           
              <center> <footer>
     <small>&copy; Copyright 2018, sosetecquiano@gmail.com </small>
            </footer>   </center>
        </div>
    </body>
</html>